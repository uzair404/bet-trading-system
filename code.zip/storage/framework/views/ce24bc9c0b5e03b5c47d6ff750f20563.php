<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('head'); ?>
        <style>
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-size: revert;
                font-weight: revert;
            }

            .IconBox>a>span {
                font-size: 1rem;
                font-weight: 700;
                margin-left: -.5rem;
            }

            .IconBox>a>img {
                width: 75px;
                transition: .2s ease;
                display: inline;
            }

            .IconBox>a>img:hover {
                transform: scale(1.25);
                cursor: pointer;
            }
        </style>
    <?php $__env->stopSection(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Blog')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg !px-4">

                <!-- Blog Post Content -->
                <div style="margin-top:1rem;" class="md:mb-0 w-full mx-auto relative">
                    <div class="px-4 lg:px-0">
                        <h2 style="font-size: 2rem;" class="font-semibold text-gray-800 leading-tight">
                            <?php echo e($post->title); ?>

                        </h2>
                        <a href="#" class="py-2 text-green-700 inline-flex items-center justify-center mb-2">
                            <?php echo e($post->category->name); ?>

                        </a>
                    </div>

                    <img src="<?php echo e(asset('uploads/thumbnails/'.$post->image)); ?>"
                        class="w-full object-cover lg:rounded" style="height: 28em;" />
                </div>

                <div class="m-4">

                    <?php echo $post->content; ?>


                </div>

                <div class="m-2 flex items-center flex-col">
                    <h2 class="2xl text-center">Whats Your Reaction?</h2>
                    <div class="reaction-icons">

                        <?php $__currentLoopData = $reactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $reaction_count = \App\Models\PostReactions::where('reaction_id', $reaction->id)->where('post_id', $post->id)->count();
                            ?>
                            <div class="inline IconBox">
                                <a href="<?php echo e(route('react', ['post_id'=>$post->id,'reaction_id'=>$reaction->id])); ?>">
                                    <img clas="reactIcon" src="<?php echo e($reaction->source); ?>"
                                        alt="Like emoji" />
                                    <span><?php echo e($reaction_count); ?></span>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="container mx-auto mt-8 p-4">

                    <h1 class="text-2xl font-bold mb-4">Comments</h1>

                    <!-- Comment Form -->
                    <div class="mb-8">
                        <form action="<?php echo e(route('comments.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <label for="comment" class="block text-gray-700 text-sm font-bold mb-2">Add a
                                Comment:</label>
                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
                            <textarea name="body" id="comment" rows="3"
                                class="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-500"></textarea>

                            <button type="submit"
                                class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:bg-blue-600">Post
                                Comment</button>
                        </form>
                    </div>

                    <!-- Existing Comments -->
                    <div>
                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-white p-4 mb-4 shadow-md rounded-md">
                                <p class="text-gray-700"><?php echo e($comment->body); ?></p>
                                <span class="text-sm text-gray-500"><?php echo e($comment->user->name); ?> -
                                    <?php echo e($comment->created_at->diffForHumans()); ?></span>

                                <!-- Delete Button -->
                                <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="post" class="mt-2">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-sm text-red-500 hover:text-red-700 focus:outline-none">Delete</button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Client Work\bet tracking system\app\resources\views/post.blade.php ENDPATH**/ ?>