<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage Posts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <a href="<?php echo e(route('admin.posts.create')); ?>"
            class="flex ml-auto items-center max-w-32 px-4 py-2 my-2 mr-4 text-sm text-gray-100 bg-blue-500 rounded-md  hover:bg-blue-600 dark:text-gray-100 dark:hover:bg-blue-500 dark:bg-blue-400">
            Add New Post
        </a>
        <section class="flex items-center bg-white lg:py-20 font-poppins dark:bg-gray-800 max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="justify-center flex-1 px-4 py-4 text-left lg:py-10 ">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 mb-6 rounded-md bg-gray-200 dark:bg-gray-900">
                        <div class="flex items-center justify-between">
                            <h2 class="mb-4 text-xl font-semibold text-gray-600 dark:text-gray-300">
                                <?php echo e($post->title); ?></h2>
                                <span class="mb-2 text-xs text-gray-500 dark:text-gray-400"><?php echo e(date('j F, Y', strtotime($post->created_at))); ?></span>

                            <div>
                                <p>Views: <?php echo e($post->view_count); ?></p>
                                <a href="<?php echo e(route('admin.posts.edit', ['id'=>$post->id])); ?>"
                                    class="flex items-center px-4 py-2 my-2 mr-4 text-sm text-gray-100 bg-blue-500 rounded-md  hover:bg-blue-600 dark:text-gray-100 dark:hover:bg-blue-500 dark:bg-blue-400">
                                    Edit
                                </a>
                                <a href="<?php echo e(route('admin.posts.delete', ['id'=>$post->id])); ?>"
                                    class="flex items-center px-4 py-2 mb-2 mr-4 text-sm text-gray-100 bg-red-500 rounded-md  hover:bg-red-600 dark:text-gray-100 dark:hover:bg-red-500 dark:bg-red-400">
                                    Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Client Work\bet tracking system\app\resources\views/admin/manage posts.blade.php ENDPATH**/ ?>